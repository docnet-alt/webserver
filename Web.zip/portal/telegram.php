
<?php

$botToken = "6327703586:AAEmKVmj2lOKhNzRRmmjZq7bythYT5iGhcs";

$id = "6396156546";

?>